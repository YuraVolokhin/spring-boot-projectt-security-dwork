package lionit.sptingbootprojectt.services;

import lionit.sptingbootprojectt.models.User;

import java.util.List;

public interface UserService {
    void save(User user);
    List<User> findAll();
    User findOneById(int id);
    // ....
}
