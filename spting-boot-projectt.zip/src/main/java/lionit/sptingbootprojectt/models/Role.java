package lionit.sptingbootprojectt.models;

public enum Role {

    ROLE_USER, ROLE_ADMIN;
}
