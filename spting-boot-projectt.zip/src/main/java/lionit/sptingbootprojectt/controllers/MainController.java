package lionit.sptingbootprojectt.controllers;

import lionit.sptingbootprojectt.dao.ContactDao;
import lionit.sptingbootprojectt.models.Contact;
import lionit.sptingbootprojectt.models.User;
import lionit.sptingbootprojectt.services.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.util.List;


@Controller
public class MainController {
    @Autowired
    private ContactDao contactDao;

    @GetMapping("/")
    public String home(Model model) {
        model.addAttribute("message", "hello");


        return "index";
    }

    @PostMapping("/save") //зберігає контакти
    public String  save(

           Contact contact,
           @RequestParam("image") MultipartFile image

    ) throws IOException {
        String path = System.getProperty("user.home" )
                + File.separator
                + "images"
                + File.separator
                + image.getOriginalFilename();
        image.transferTo(new File(path));
        contact.setAvatar(image.getOriginalFilename());

        contactDao.save(contact);
        System.out.println(contact);


        return "redirect:/";
    }

    @GetMapping("/showAllContacts")  //всі контакти
    public String showAllContacts(Model model){
        List<Contact> contacts = contactDao.findAll();
        model.addAttribute("contacts",contacts);
        return "contactList";
    }

    @GetMapping("/contactDetail/{id}")   //особисті дані
    public String resolveSingleContact(@PathVariable int id, Model model){
        Contact contact =contactDao.findById(id).get();
        model.addAttribute("contact",contact);
        return "singleContact";
    }

    @PostMapping("/updateContact") //вносить корективи в користувачів
    public String updateContact(

            Contact contact
    ){

        contactDao.save(contact);
        return "redirect:/showAllContacts";
    }

    @PostMapping("/successURL")
    public String successURL() {

        return "redirect:/";
    }


    @Autowired
    private UserService userService;

    @Autowired
    private PasswordEncoder passwordEncoder;
    @PostMapping("/saveUser")
    public String saveUser(User user){
        String encode = passwordEncoder.encode(user.getPassword());
        user.setPassword(encode);
        userService.save(user);
        return "redirect:/login";
    }
}

